package com.trnqb.cafe.dto;

public enum Role {
    USER,
    ADMIN
}
